package com.rkit;

public class A {
A(){
	System.out.println("A created");
}
}
