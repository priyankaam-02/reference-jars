package com.rkit;
import org.springframework.stereotype.Component;

@Component
public class Z {
	Z(){
		System.out.println("Z created....");
	}

}
