import java.lang.reflect.Method;
import java.util.Map;

import org.springframework.beans.factory.support.MethodReplacer;

public class Shop {
	private String festival;
	private int amount;
	public String getFestival() {
		return festival;
	}

	public void setFestival(String festival) {
		this.festival = festival;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	public  int getDiscount() {
		
		return 0;
	};
}
class DiscountReplacer implements MethodReplacer{
	
	private int discount;
	private String customerName;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public static DiscountReplacer getInstance() {
		return new DiscountReplacer();
	}
	@Override
	public Object reimplement(Object arg0, Method method, Object[] arg2) throws Throwable {
		System.out.println("Custoemr Name is "+this.customerName);
		return this.discount;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	
	
}

