import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
	private static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		ApplicationContext container = new ClassPathXmlApplicationContext("app-config.xml");//All objects created here
		/*Magician magician = (Magician) container.getBean("magician");
		System.out.println("shich class Object is this ? "+magician.getClass().getName());
		System.out.println(magician.getBox().showContent());
		 */
		Shop shop = (Shop) container.getBean("shop");
		while(true) {
			System.out.println(" We offer "+shop.getDiscount()+"% discount");
		}

	}

}
