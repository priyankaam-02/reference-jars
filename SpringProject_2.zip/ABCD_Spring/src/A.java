
public class A implements I{
	private B b;
	private int rate;
	private int amount;
	private int duration;
	private int yearlyInterestEarned;
	
	public int getRate() {
		
		return rate;
	}
	public void setRate(int rate) {
		System.out.println("Set Rate called ");
		this.rate = rate;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		System.out.println("Set Amount called ");
		this.amount = amount;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		System.out.println("Set Duration called ");
		this.duration = duration;
	}
	public int getYearlyInterestEarned() {
		return yearlyInterestEarned;
	}
	
	public void calculateYearlyInterest() {
		System.out.println("Caculate Yearly Interest called ");
		this.yearlyInterestEarned = this.amount*this.duration*this.rate/100;
	}
	public B getB() {
		return b;
	}
	A(B b){
		this.b = b;
		System.out.println("Parameterized constructor of A called");
	}
	A(){
		System.out.println("Default constructor of A");
	}
	public void m1() {
		System.out.println("m1 of A");
	}
	public void setB(B b) {
		this.b = b;
		System.out.println("setB() of A called");
	}
	
	public void reset() {
		System.out.println("Reset Method called");
		this.yearlyInterestEarned=0;
	}
}
