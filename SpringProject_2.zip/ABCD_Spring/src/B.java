import java.util.List;

public class B {
	private String s;
	private List<String> strings;
	private List<Integer> inetegers;
	public B(String s){
		this.s = s;
		System.out.println("Parameterized constructor of B");
	}
	public B() {
		System.out.println("Default Constructor of B");
	}
	public B(String s, List<String> strings) {
		this.strings = strings;
		System.out.println("List of strings received in Constructor");
		System.out.println(strings);
	}
	public void setS(String s) {
		this.s = s;
		System.out.println("SetS() method called");
	}
	public List<String> getStrings() {
		return strings;
	}
	public void setStrings(List<String> strings) {
		this.strings = strings;
		System.out.println("setStrings called : "+strings);
	}
	public List<Integer> getInetegers() {
		return inetegers;
	}
	public void setInetegers(List<Integer> inetegers) {
		this.inetegers = inetegers;
		System.out.println("setIntegers called : "+inetegers);
	}
	

}
