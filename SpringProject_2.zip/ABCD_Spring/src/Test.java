import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext container = new ClassPathXmlApplicationContext("app-config.xml");//All objects created here
		A a = container.getBean(A.class);
		System.out.println(a.getYearlyInterestEarned());
		//((ClassPathXmlApplicationContext)container).close();//this will destroy all beans created at startup
		
	}

}
