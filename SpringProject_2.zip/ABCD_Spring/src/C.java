
public class C {
	private C() {
		System.out.println("constructor called");
	}
	
	public static C getInstance() {
		//This has some big logic like connect DB, get some values from DB
		//Then initialize the properties
		System.out.println("Inside getInstance method about to create Object ");
		return new C();
	}

}
