
public interface I {
	void m1();

}
