package com.rits;

public interface MagicBox {
	String showContents(String val);

}
