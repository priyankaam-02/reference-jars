package com.rits;

import java.lang.reflect.Method;

import org.springframework.beans.factory.support.MethodReplacer;

public class ElephantReplacer implements MethodReplacer {

	

}
