package com.rits;

public class BeautifulAssistantBox implements MagicBox {
	
	public BeautifulAssistantBox() {
		super();
		
	}

	@Override
	public String getContents() {
		
			return "A beautiful Assitant";
		
	}

}
