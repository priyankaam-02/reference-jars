package bank.server.internal;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Class c =  X.class;
       A x =  new X();
	}

}

class X{
	
}
