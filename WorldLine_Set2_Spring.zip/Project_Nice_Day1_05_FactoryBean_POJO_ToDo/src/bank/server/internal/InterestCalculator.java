package bank.server.internal;

public class InterestCalculator {
	
	public int getInterest() {
		System.out.println("getInterest Called");
		return 11;
	}

}
