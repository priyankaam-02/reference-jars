package com.worldline.jpa;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
@Controller
@PropertySource("classpath:/bank.properties")
public class HelloController {
	
	@Autowired
	AccountRepository repository;
	@Value("${bank.title}") String title;
	@Value("${bank.welcome}") String welcomeMessage;
	@GetMapping("/showform")	
	public String sayHello(Model model) {
		model.addAttribute("title",title);
		return "views/account";
	}	
	@PostMapping(value="/save")
	public String save(HttpSession session, Model model, Account account ) {
		session.setAttribute("hello","Hi!!!!");
		model.addAttribute("welcome",welcomeMessage);
		model.addAttribute("acct",account);
		System.out.println(account);
		repository.save(account);
		return "views/success";
		
	}
	
}
/*
 * 1. Create views  folder under src/main/resources/templates
 * 2. Open application.properties file and make following entry
 * bank.title=Welcome to Worldline Bank
 * 3. create account.html file and make following entry 
 * <h1 th:text="${title}">
 * <form action="/save" method="post">
 * Name:<input type="text" name="name"><br/>
 * id:<input type="text" name="name"><br/>
 * Balance:<input type="text" name="name"><br/>
 * <input type="submit">
 * </form>
 * <div id="response"></div>
 */
