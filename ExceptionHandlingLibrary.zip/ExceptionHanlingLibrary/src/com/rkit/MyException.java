package com.rkit;

public class MyException extends Exception {

}
