

public interface School {
	void takeAdmission(String name, int age);
	
	

}
