import java.util.Set;
import java.util.TreeSet;

public class TestTreeSet {

	public static void main(String[] args) {
		Set set = new TreeSet();
		Student s1 = new Student("A","B","Pune","Bharat",20);
		Student s2 = new Student("P","B","Dallas","America",35);
		Student s3 = new Student("C","C","Frankfurt","Germany",50);
		Student s4 = new Student("X","B","Kyoto","Japan",80);
		Student s5 = new Student("B","B","Mumbai","Bharat",16);
        set.add(s1);
        set.add(s2);
        set.add(s3);
        set.add(s4);
        System.out.println("Size = "+set.size());
        set.add(s5);
        System.out.println("Size = "+set.size());
        System.out.println(set);
        Set set2 = new TreeSet(new SortByfname());
        set2.addAll(set);
        System.out.println("***** By First Name");
        System.out.println(set2);
        Set set3 = new TreeSet(new SortByLname());
        set3.addAll(set);
        System.out.println("***** By Last Name Name");
        System.out.println(set3);
        Set set4 = new TreeSet(new SortAge());
        set4.addAll(set);
        System.out.println("***** By Age ****");
        System.out.println(set4);

        
	}

}

//TreeSet is 
