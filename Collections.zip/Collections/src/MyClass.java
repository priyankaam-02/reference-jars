//Named implementation Class
public class MyClass implements I{

	@Override
	public void m1() {
		System.out.println("m1 from MyClass ");
		
	}

}
