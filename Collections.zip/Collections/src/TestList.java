import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
import java.util.function.Consumer;

public class TestList {

	public static void main(String[] args) {
		List l = new Vector();//Raw List, It can accomodate heterogeneous object.
		
		l.add("Hello");//0
		l.add("Namaste");//1
		l.add(100);//2			
		int no = (int) l.get(2);
		System.out.println("Third element is "+no);//100
		l.add(2,200);
		no = (int) l.get(2);
		System.out.println("Third element is "+no);//200
		no = (int) l.get(3);
		System.out.println("Fourth element is "+no);//100
		
		/*
		 * 1. How to create arraylist
		 * 2. How to add objects to list
		 * 3. How to check size of arraylist
		 * 4. How to remove/removeAll
		 * 5. How to get elements at particular index.
		 * 6. How to add elements at particular index.
		 */
		//How to iterate / traverse the List
		//Method-I using index
		System.out.println("**----Method-I using index and for loop-----**");
		for(int i=0; i< l.size(); i++) {
			System.out.println(l.get(i));
		}
		System.out.println("**----Method-II using enhanced for loop-----**");
		//Method-II using enhanced for loop
		for(Object obj : l) {
			System.out.println(obj);
		}
		//Method-III using iterator() method
		System.out.println("**----Method-III using iterator-----**");
		ListIterator i = l.listIterator();
		while(i.hasNext()) {
			System.out.println(i.next());
			System.out.println(i.previous());
		}
		//Method-IV using forEach and lambda expression
		System.out.println("**----Method-IV using lambda expression-----**");
		Consumer xyz = (Object o)->{ System.out.println(o);};//lambda expression
		//Declare an object reference "printElements" of type Consumer;
		l.forEach(xyz);//it calls xyz(element from l) 4 times
	
	}

}
