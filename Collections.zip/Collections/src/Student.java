import java.util.HashSet;
import java.util.Set;

public class Student implements Comparable<Student>{
	String fname;
	String lname;
	int age;
	String city;
	String country;
	
	public Student(String fname, String lname, String city, String country, int age) {
		this.fname   = fname;
		this.lname   = lname;
		this.city    = city;
		this.country = country;
		this.age     = age;
	}	
	@Override
	public int compareTo(Student existingObject) {
		
		// equality is based on fname and lname
		
		return this.age-existingObject.age;
	}



	@Override
	public String toString() {
		return "Student [fname=" + fname + ", lname=" + lname + ", age=" + age + ", city=" + city + ", country="
				+ country + "age = "+age+" ]";
	}
	

}
