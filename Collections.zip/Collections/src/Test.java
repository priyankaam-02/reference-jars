
public class Test {

	public static void main(String[] args) {
		//3 Different ways to create an Object of Implementation Class of an interface
		//1. Create Object of named implementation of I
		
		I i = new MyClass();
		i.m2("hello",100);
		
		//2. Create object of un-named/anonymous implementation of I
		I i1 = new I() {
			
			public void m2(String s,int j) {
				System.out.println("m2 of anonymous implementation s = "+s);
			}
		};
		
		i1.m2("hello",800);
		//3 . Lambda expression which is also an object of un-named/anonymous Implementation of functional interface
       I i2 = (s,j)-> {
			 System.out.println("m1 of lambda "+s);
		    }  ;
		    i2.m2("hello",200);
	}

}

