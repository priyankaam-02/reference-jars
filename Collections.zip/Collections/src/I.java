
public interface I {
	 
	 void m2(String s, int i);

}
