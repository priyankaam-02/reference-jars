import java.util.HashSet;
import java.util.Set;

public class TestSet {

	public static void main(String[] args) {
		Set<String> s = new HashSet();
		boolean status = s.add(new String("Bharat"));
		//add method calls hashCode method of object getting added
		//whose method will be called by add()?
		//what is Bharat ???? is it an object of String
		//which class method will be called ?
		status = s.add("Mata");
		System.out.println(status);
		status = s.add("Ki");
		System.out.println(status);
		status = s.add("Jai");
		System.out.println(status);
		System.out.println("No of elements added so far "+s.size());
		status = s.add(new String("Bharat"));//It detects that "Bharat" is already added the set.
		System.out.println(status);
		System.out.println("No of elements added so far "+s.size());
		for(String str : s) {
			System.out.println(str);
		}
		

	}

}
