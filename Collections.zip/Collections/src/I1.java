
public interface I1 {
	void m1(int i, int j, String s);
}
interface I2 {	
	void m2(String s);
}
interface I3 {
	int getInt();
}

//Assignment is 
//First created Named implementation classes.
//Then use lambda expression (so that those named classes are not required)
// Write main method which calls methods on following class
class TestMyLambdaKnowledge{
	public void takeI1(I1 i){
		i.m1(10,15,"Hello");
	}
	public void takeI2(I2 i){
		i.m2("Namaste");
	}
	public void takeI3(I3 i){
		i.getInt();
	}
}