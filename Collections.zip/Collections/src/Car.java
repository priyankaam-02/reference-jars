import java.util.HashSet;
import java.util.Set;

public class Car {
	String color;
	int yearofmanufacturing;
	String make;
	String model;
	int engineCapacity;
	int noofdoors;
	float weight;
	float volume;//size

	public Car(String color, int yearofmanufacturing, String make, String model, int engineCapacity, int noofdoors,
			float weight, float volume) {
		super();
		this.color = color;
		this.yearofmanufacturing = yearofmanufacturing;
		this.make = make;
		this.model = model;
		this.engineCapacity = engineCapacity;
		this.noofdoors = noofdoors;
		this.weight = weight;
		this.volume = volume;
	}
	@Override
	public int hashCode() {
		System.out.println("hashCode called ");
		return this.engineCapacity;
	}
	public boolean equals(Object obj) {
		System.out.println("equals called ");
		if(obj instanceof Car) {
			Car existingCar = (Car)obj;//If your set contains heterogenours, if Set has Fruits, ANimals, Cars you will get ClassCastException
			if(existingCar.engineCapacity== this.engineCapacity && existingCar.color.equals(this.color)) {
				return true;
			}
			return false;//Add to Set (its is unique)
		}
		return true;//Object is not stored 
	}

	public static void main(String[] args) {
		 Set<Car> s = new HashSet<Car>();//Only Cars can be stored.
		 Car c1 = new Car("Blue",2013,"Toyota","Innova",2251,4,1500,1234);
		 s.add(c1);
		// System.out.println("Bucket number for newly added car is "+c1.hashCode()); 
		 System.out.println("No of cars "+s.size());
		 Car c2 = new Car("White",2014,"Honda","CRV",2250,4,234,2345);
		 boolean isadded = s.add(c2);
		// System.out.println("Bucket number for secondly added car is "+c2.hashCode());
		 System.out.println("Is added ? "+isadded);
		 System.out.println("No of cars "+s.size());
		 
	}
}
//override hashCode() and equals() method if business requirement is : 2 cars are equal if color and engineCapacity is same.
//Rule says if 2 objects are equal then hashCode must be same.