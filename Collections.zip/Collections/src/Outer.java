
public interface Map {
	
	interface Entry<K,V>{}

}
class X{
	public static void main(String[] args) {
		Set<Map.Entry<Customer,Address>> inner;
	}
}
