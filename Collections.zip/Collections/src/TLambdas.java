import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;

public class TLambdas {

	public static void main(String[] args) {
		//Lambda expression is an object
		//Object of a class 
		//Which class ?
		//an implementation class of ?
		//Some interface (but only if interface has 1 abstract method)
		School s = (String name, int age)-> {System.out.println("Admission granted to "+name+" age = "+age);	};
		List<String> list = Arrays.asList("A","X","P","m");
		Consumer<String> c = (str)-> {System.out.println(str);};
		list.forEach(c);
	}
}



	

