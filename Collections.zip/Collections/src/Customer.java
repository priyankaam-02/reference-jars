
public class Customer {
   private String fname;
   private int id;
   
   @Override
   public int hashCode() {
	   return id;
   }
   @Override
   public boolean equals(Object obj) {
	   Customer c = (Customer)obj;
	   return c.id==this.id;
   }
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
@Override
public String toString() {
	return "Customer [fname=" + fname + ", id=" + id + "]";
}
   
  
}


