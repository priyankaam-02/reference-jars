package com.rkit;

public class Log extends Actions {

	@Override
	public void takeAction(String str) {
		// TODO Auto-generated method stub
		System.out.println("Logged");
	}

	
}
