package com.rkit;

public class SMS extends Actions{

	@Override
	public void takeAction(String str) {
		// TODO Auto-generated method stub
		System.out.println("SMS Send");
	}
	

}
