package com.rkit;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class XMLUtility {

	static String[][] classNameMethodNameExceptionname = new String[2][10];
	static String[][]exceptionAndEmailConfig=new String[2][10];
	
	public static void loadAndParseXML(String fileName) {
		
		DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
		try {
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			Document doc = builder.parse(fileName);//document is a Tree , Nodes
			Node rootNode = doc.getDocumentElement();
			System.out.println("Name of root node is "+rootNode.getNodeName());
			//Get All Classes
			NodeList classNodes = rootNode.getChildNodes();//Class Names
			int keyCounter=0;
			int actionCounter=0;
			int exCount=0;
			int mailCount=0;
			for(int i=0; i< classNodes.getLength();i++) {
				
				Node classNode = classNodes.item(i);
				if(classNode.getNodeType()==Node.ELEMENT_NODE) {
					
					String className = ((Element)classNode).getAttribute("name");
					
					System.out.println("class Name is "+className);
					//getMethodNames
					NodeList methodNodes = classNode.getChildNodes();
					for(int j=0; j< methodNodes.getLength();j++) {
						Node methodNode = methodNodes.item(j);
						if(methodNode.getNodeType()==Node.ELEMENT_NODE) {
							String methodName = ((Element)methodNode).getAttribute("name");
							
							System.out.println("Method Name is "+methodName);
							NodeList exceptionNodes = methodNode.getChildNodes();
							
							for(int k=0; k< exceptionNodes.getLength();k++) {
								Node exceptionNode = exceptionNodes.item(k);
								StringBuilder key = new StringBuilder("");
								key.append(className+"#");
								key.append(methodName+"#");
								if(exceptionNode.getNodeType()==Node.ELEMENT_NODE) {
									String exceptionName = ((Element)exceptionNode).getAttribute("name");
									System.out.println("Method Name is "+exceptionName);
									key.append(exceptionName);
									System.out.println(key.toString());
									classNameMethodNameExceptionname[0][keyCounter++] = key.toString();
									
									//Get List of ACtions
									NodeList actionNodes = exceptionNode.getChildNodes();
									StringBuilder actions= new StringBuilder();
									for(int l=0; l< actionNodes.getLength();l++) {
										Node actionNode = actionNodes.item(l);
										if(actionNode.getNodeType()==Node.ELEMENT_NODE) {
											String actionNodeName = ((Element)actionNode).getNodeName();
											
											
											if (actionNodeName.equals("Email")) {
												NamedNodeMap map=actionNode.getAttributes();
												StringBuilder atri= new StringBuilder();
												
												String atrToName=map.getNamedItem("to").getNodeValue();
												String atrCCName=map.getNamedItem("cc").getNodeValue();
												String atrSubName=map.getNamedItem("subject").getNodeValue();
												atri.append(atrToName+","+atrCCName+","+atrSubName);
												exceptionAndEmailConfig[0][exCount++]=exceptionName;
												exceptionAndEmailConfig[1][mailCount++]=atri.toString();
											}
											
											
										//	System.out.println("Action Name is "+actionNodeName);
											//Get List of ACtions
											if(l<actionNodes.getLength())
											actions.append(actionNodeName+",");
											
											System.out.println("Actions "+actions.toString());
										}
									}
									classNameMethodNameExceptionname[1][actionCounter++] = actions.toString();
								}
							}
						}
					}
				}
			}
//		System.out.println("********** KEYS **********");
//				for(int j=0; j<10;j++) {
//					if(classNameMethodNameExceptionname[0][j] !=null) {
//				       System.out.println("111"+classNameMethodNameExceptionname[0][j]);
//				       System.out.println("  ###  "+classNameMethodNameExceptionname[1][j]);
//					}
//			}
				
//				System.out.println("********** ExceptioMail **********");
//				for(int j=0; j<10;j++) {
//					if(exceptionAndEmailConfig[0][j] !=null) {
//				       System.out.println("111"+exceptionAndEmailConfig[0][j]);
//				       System.out.println("  ###  "+exceptionAndEmailConfig[1][j]);
//					}
//			}
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String searchMail(String key) {
		// TODO Auto-generated method stub
//	String action[]=new String[1];	
		for(int j=0; j<10;j++) {
			if (exceptionAndEmailConfig[0][j].contains(key)) {
				String action=exceptionAndEmailConfig[1][j];
				return action;
			}
		}
		return null;
	}
	
	public String[] searchActionsforAkey(String key) {
		// TODO Auto-generated method stub
//	String action[]=new String[1];	
		for(int j=0; j<10;j++) {
			if (classNameMethodNameExceptionname[0][j].contains(key)) {
				String action[]=classNameMethodNameExceptionname[1][j].split(",");
				return action;
			}
		}
		return null;
	}
}
