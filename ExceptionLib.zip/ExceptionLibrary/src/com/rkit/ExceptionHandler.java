package com.rkit;


public class ExceptionHandler extends XMLUtility {
    void handleException(String className, String methodName, Exception e) {
    	 loadAndParseXML("ExceptionConfig.xml");
    	//1. Get List of actions to be taken from config based on 3 args(className, methodName, Exception)
    	    //1. I will assume for my design that config is inside an xml 
    	    //1. Load that XML , parse XML and then get List actions for given 3 params.
    	    //Concatenating these 3 parameters and create a string
    	      String key = className+"#"+methodName+"#"+e.getClass().getSimpleName();
    	      StringBuffer msg=new StringBuffer();
    	      
  	      if (e.getClass().getSimpleName().equals("MyException")) {
			 msg.append(searchMail(e.getClass().getSimpleName()));
		} 
    	     String[] actions = searchActionsforAkey(key);
    	     for(String action : actions) {
    	    	 //call appropriate action method.
    	    	 
					Class cl;
					try {
						cl = Class.forName("com.rkit."+action);
						Actions act=(Actions) cl.newInstance();
						act.takeAction(msg.toString());
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InstantiationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
    	     }
    	    	     
    	// Using this string we get list of actions
    	//e.g.
    //	A#m1#MyException   [Email,Log]
    	  
    	//2. Iterate over the list of actions and take that action
    }

	public static void main(String[] args) {
		MyException e=new MyException();
		new ExceptionHandler().handleException("com.rkit.A", "m1", e);
		
		
//				loadAndParseXML("ExceptionConfig.xml");
	}
	
}
