package com.rkit;

public class Email extends Actions {

	@Override
	public void takeAction(String str) {
		// TODO Auto-generated method stub
		String [] arr=str.split(",");
		
		System.out.println("Email Send To: "+arr[0]+" CC: "+arr[1]+" Subject: "+arr[2]);
	}

	
}
