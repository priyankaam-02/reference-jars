package com.rkit;

public abstract class Actions {

	abstract void takeAction(String str);
}